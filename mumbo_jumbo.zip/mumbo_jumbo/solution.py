# %% [markdown]
# # Neural Network Reconstruction from Scrambled Weight Pieces
#
# A small residual MLP (originally trained on MNIST) was split into its
# individual weight tensors and shuffled. This notebook reconstructs the
# original model in three steps:
#
# 1. **Identify pieces** — classify each saved tensor by its shape into one
#    of four roles: input projection, output classifier, or a residual
#    block's "in" / "out" linear layer.
# 2. **Initial pairing** — pair each "in" piece with an "out" piece using
#    the heuristic that, in a residual block, `W_out ≈ -W_in^T` for the
#    weights that were trained together (a coarse, fast guess).
# 3. **Order the 32 paired blocks** — search over permutations of the
#    blocks until the reconstructed model's logits match the saved
#    reference logits (MSE → 0). The search combines random-swap local
#    search with an LCS-based "repair" step that merges two independent
#    solutions.

# %%
import os
import random

import pandas as pd
import torch
import torch.nn as nn

# %%
# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
DATA_DIR = "data"
HISTORY_CSV = os.path.join(DATA_DIR, "history_data.csv")
PIECES_DIR = os.path.join(DATA_DIR, "pieces")

MODEL_OUT = "final_model.pth"
SUBMISSION_OUT = "submission.csv"

NUM_CLASSES = 10
IMAGE_PIXELS = 28 * 28  # MNIST images are 28x28

# %% [markdown]
# ## 1. Load the reference data
#
# `history_data.csv` contains, for a batch of MNIST images, both the raw
# pixels and the *original* model's output logits. These logits are the
# ground truth we reconstruct against — we don't need the model's weights
# directly, only a forward pass that reproduces the same logits.

# %%
df = pd.read_csv(HISTORY_CSV)
print(f"Historical dataset shape: {df.shape}")

pixel_cols = [f"pixel_{i}" for i in range(IMAGE_PIXELS)]
X = torch.tensor(df[pixel_cols].values, dtype=torch.float32)

logit_cols = [f"pred_logit_{i}" for i in range(NUM_CLASSES)]
target_logits = torch.tensor(df[logit_cols].values, dtype=torch.float32)

true_labels = torch.tensor(df["true_label"].values, dtype=torch.long)

print(
    f"Loaded {X.shape[0]} images. "
    f"Features X shape: {X.shape} | Logits shape: {target_logits.shape}"
)

# %% [markdown]
# ## 2. Load and classify the scrambled weight pieces
#
# Each `.pth` file holds one `{weight, bias}` pair. The model's architecture
# is fixed and known in advance, so every tensor's role can be identified
# purely from its shape:
#
# | Shape       | Role                                   |
# |-------------|-----------------------------------------|
# | (16, 784)   | Input projection (`proj`): pixels → 16d  |
# | (10, 16)    | Output classifier (`last`): 16d → logits |
# | (32, 16)    | A residual block's "in" layer (16 → 32)  |
# | (16, 32)    | A residual block's "out" layer (32 → 16) |

# %%
piece_files = [f for f in os.listdir(PIECES_DIR) if f.endswith(".pth")]

proj_layer = None
last_layer = None
inp_pieces = []
out_pieces = []

for filename in piece_files:
    path = os.path.join(PIECES_DIR, filename)
    obj = torch.load(path, map_location="cpu")
    weight, bias = obj["weight"], obj["bias"]

    if weight.shape == (16, 784):
        proj_layer = {"filename": filename, "weight": weight, "bias": bias}
    elif weight.shape == (10, 16):
        last_layer = {"filename": filename, "weight": weight, "bias": bias}
    elif weight.shape == (32, 16):
        inp_pieces.append({"filename": filename, "weight": weight, "bias": bias})
    elif weight.shape == (16, 32):
        out_pieces.append({"filename": filename, "weight": weight, "bias": bias})

print("Isolated components:")
print(f"  - Input projection (`proj`):     {proj_layer['filename']}")
print(f"  - Output classifier (`last`):    {last_layer['filename']}")
print(f"  - Residual block 'in' layers:    {len(inp_pieces)} pieces")
print(f"  - Residual block 'out' layers:   {len(out_pieces)} pieces")

# %% [markdown]
# ## 3. Pre-compute the fixed parts of the forward pass
#
# `proj` and `last` are unambiguous (only one piece matches each shape), so
# we can apply the input projection once up front instead of recomputing it
# on every candidate ordering.

# %%
BASE_X = X @ proj_layer["weight"].t() + proj_layer["bias"]

# %%
def evaluate_reconstruction(ordered_blocks):
    """
    Run the forward pass for a candidate block ordering and score it
    against the reference logits.

    Args:
        ordered_blocks: List of 32 dicts, each with keys
            'inp_weight', 'inp_bias', 'out_weight', 'out_bias',
            representing one residual block in the proposed order.

    Returns:
        float: Mean-squared error between the reconstructed logits and
        `target_logits`. A perfect reconstruction scores ~0.
    """
    curr_x = BASE_X

    for block in ordered_blocks:
        w_in, b_in = block["inp_weight"], block["inp_bias"]
        w_out, b_out = block["out_weight"], block["out_bias"]
        # Residual update: x = x + W_out @ relu(W_in @ x + b_in) + b_out
        curr_x = curr_x + torch.relu(curr_x @ w_in.t() + b_in) @ w_out.t() + b_out

    logits = curr_x @ last_layer["weight"].t() + last_layer["bias"]
    return torch.mean((logits - target_logits) ** 2).item()

# %% [markdown]
# ## 4. Initial pairing: match "in" pieces to "out" pieces
#
# Within a single trained residual block, the "in" and "out" weights tend to
# be near-mirror images of each other (`W_out ≈ -W_in^T`), since the block
# computes `x + W_out @ relu(W_in @ x + b_in) + b_out`. We use this as a
# cheap heuristic to guess which "out" piece originally belonged with each
# "in" piece, via greedy nearest-neighbor matching.
#
# This only recovers *pairings*, not the order in which the 32 paired
# blocks were originally stacked — that's handled by the search in step 6.

# %%
random.seed(42)


def pair_blocks(inp_pieces, out_pieces):
    """Greedily pair each 'in' piece with its closest 'out' piece by
    minimizing ||W_out + W_in^T||."""
    remaining_out = list(out_pieces)
    pairs = []

    for p_in in inp_pieces:
        w_in = p_in["weight"]

        best_idx, best_diff = None, float("inf")
        for idx, p_out in enumerate(remaining_out):
            w_out = p_out["weight"]
            diff = torch.norm(w_out + w_in.t()).item()
            if diff < best_diff:
                best_idx, best_diff = idx, diff

        best_out = remaining_out.pop(best_idx)
        pairs.append({"inp": p_in, "out": best_out, "score": best_diff})

    return pairs


paired_blocks = pair_blocks(inp_pieces, out_pieces)

# Flatten into an (in, out, in, out, ...) sequence for build_ordered_blocks.
flat_pieces = []
for pair in paired_blocks:
    flat_pieces.append(pair["inp"])
    flat_pieces.append(pair["out"])

# %%
def build_ordered_blocks(flat_pieces):
    """
    Convert a flat (in, out, in, out, ...) sequence into a list of block
    dicts consumable by `evaluate_reconstruction`. The initial ordering
    here is arbitrary — it just reflects the order pieces were paired in,
    not the network's true block order.
    """
    ordered_blocks = []

    for i in range(0, len(flat_pieces), 2):
        inp, out = flat_pieces[i], flat_pieces[i + 1]
        ordered_blocks.append({
            "inp_weight": inp["weight"],
            "inp_bias": inp["bias"],
            "out_weight": out["weight"],
            "out_bias": out["bias"],
            "inp_filename": inp["filename"],
            "out_filename": out["filename"],
        })

    return ordered_blocks


curr_seq = build_ordered_blocks(flat_pieces)

# %%
print(f"MSE before ordering search: {evaluate_reconstruction(curr_seq):.8f}")

# %% [markdown]
# ## 5. Stochastic search over block orderings
#
# The pairing step tells us *which* 16 blocks exist, but not the order they
# were stacked in. `optimize_blocks` performs a simple stochastic local
# search (random pairwise swaps, keep only improving moves) to find the
# ordering that drives the reconstruction MSE to zero. It's a hill-climbing
# search, not simulated annealing — once we have an improvement we lock it
# in, and we never accept a worse swap.

# %%
def optimize_blocks(curr_seq, evaluate_mse, seed=42, iterations=2500, verbose=True):
    """
    Hill-climb over block orderings using random pairwise swaps.

    At each iteration, two positions are swapped at random. The swap is
    kept if it improves (lowers) the MSE, otherwise it's undone. Stops
    early if a near-perfect ordering (MSE <= 1e-8) is found.

    Returns:
        (list, float): the best ordering found and its MSE.
    """
    random.seed(seed)
    current = list(curr_seq)  # work on a copy; leave the input untouched

    best_mse = evaluate_mse(current)
    if verbose:
        print(f"seed={seed} initial_mse={best_mse:.8f}")

    for step in range(iterations):
        i, j = random.sample(range(len(current)), 2)
        current[i], current[j] = current[j], current[i]

        mse = evaluate_mse(current)

        if mse < best_mse:
            improvement = best_mse - mse
            best_mse = mse

            if verbose:
                print(
                    f"iter={step:5d} swap=({i:2d},{j:2d}) "
                    f"improvement={improvement:.8f} mse={best_mse:.8f}"
                )

            if best_mse <= 1e-8:
                if verbose:
                    print(f"\nPerfect solution found at iteration {step}")
                return list(current), best_mse
        else:
            # Revert the swap — it didn't help.
            current[i], current[j] = current[j], current[i]

        if verbose and step % 500 == 0 and step > 0:
            print(f"iter={step:5d} best_mse={best_mse:.8f}")

    return list(current), best_mse

# %% [markdown]
# ## 6. Merging two independent solutions (LCS repair)
#
# A single random-swap search sometimes stalls in a local optimum before
# reaching zero MSE. Running the search twice with different seeds tends
# to produce two *partially* correct orderings that agree on a subsequence
# of blocks but disagree elsewhere.
#
# `repair_from_two_solutions` finds the longest common subsequence (by
# block identity, not value) between the two orderings, treats that shared
# subsequence as "trusted," and re-inserts each remaining block at
# whichever position in the trusted sequence minimizes MSE. This is more
# effective than restarting the random search from scratch, since it
# preserves whatever both runs already agree on.

# %%
def lcs(a, b):
    """Standard longest-common-subsequence over two sequences of items."""
    n, m = len(a), len(b)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n):
        for j in range(m):
            dp[i + 1][j + 1] = (
                dp[i][j] + 1 if a[i] == b[j] else max(dp[i][j + 1], dp[i + 1][j])
            )

    out = []
    i, j = n, m
    while i and j:
        if a[i - 1] == b[j - 1]:
            out.append(a[i - 1])
            i -= 1
            j -= 1
        elif dp[i - 1][j] >= dp[i][j - 1]:
            i -= 1
        else:
            j -= 1

    return out[::-1]


def repair_from_two_solutions(seq1, seq2, evaluate_mse):
    """
    Combine two candidate orderings into one by keeping their longest
    common subsequence (by block identity) fixed, then greedily
    re-inserting the blocks that differ at whichever position minimizes
    MSE.

    Returns:
        (list, float): the merged ordering and its MSE.
    """
    ids1 = [id(x) for x in seq1]
    ids2 = [id(x) for x in seq2]

    common_ids = lcs(ids1, ids2)
    common_set = set(common_ids)

    lookup = {id(x): x for x in seq1}
    seq = [lookup[i] for i in common_ids]
    missing = [x for x in seq1 if id(x) not in common_set]

    best_mse = None
    for block in missing:
        best_mse, best_seq = float("inf"), None

        for pos in range(len(seq) + 1):
            candidate = seq[:pos] + [block] + seq[pos:]
            mse = evaluate_mse(candidate)
            if mse < best_mse:
                best_mse, best_seq = mse, candidate

        seq = best_seq
        print(f"remaining={len(missing)} mse={best_mse:.8f}")

    return seq, best_mse

# %% [markdown]
# ## 7. Top-level solver
#
# Repeats the cycle of [search, search, repair] across multiple rounds with
# fresh random seeds each time, returning early as soon as any candidate
# reaches a near-zero MSE.

# %%
def solve_with_lcs_repair(
    curr_seq,
    optimize_blocks,
    evaluate_mse,
    seed1=42,
    seed2=10,
    iterations=5000,
    max_rounds=5,
):
    """
    Alternate between independent stochastic searches and LCS-based
    repair until a near-perfect ordering (MSE <= 1e-8) is found or
    `max_rounds` is exhausted.

    Returns:
        (list, float): the best ordering found and its MSE.
    """
    best_seq, best_mse = None, float("inf")

    for round_idx in range(max_rounds):
        print(f"\n=== round {round_idx} seeds=({seed1},{seed2}) ===")

        seq1, mse1 = optimize_blocks(curr_seq, evaluate_mse, seed=seed1, iterations=iterations)
        print(f"seed={seed1} mse={mse1:.8f}")
        if mse1 < best_mse:
            best_seq, best_mse = seq1, mse1
        if mse1 <= 1e-8:
            return seq1, mse1

        seq2, mse2 = optimize_blocks(curr_seq, evaluate_mse, seed=seed2, iterations=iterations)
        print(f"seed={seed2} mse={mse2:.8f}")
        if mse2 < best_mse:
            best_seq, best_mse = seq2, mse2
        if mse2 <= 1e-8:
            return seq2, mse2

        repaired_seq, repaired_mse = repair_from_two_solutions(seq1, seq2, evaluate_mse)
        print(f"repair mse={repaired_mse:.8f}")
        if repaired_mse < best_mse:
            best_seq, best_mse = repaired_seq, repaired_mse
        if repaired_mse <= 1e-8:
            return repaired_seq, repaired_mse

        # Fresh seeds for the next round.
        seed1 = random.randint(0, 100)
        seed2 = random.randint(0, 100)

    return best_seq, best_mse


# %%
final_seq, final_mse = solve_with_lcs_repair(
    curr_seq,
    optimize_blocks,
    evaluate_reconstruction,
)

# %% [markdown]
# ## 8. Rebuild the model as a proper `nn.Module`, verify, and save
#
# With the correct ordering found, we load the pieces into a real PyTorch
# module (so it can be used/exported normally) and confirm the forward-pass
# MSE matches what the search reported.

# %%
class ResBlock(nn.Module):
    """A single residual block: x -> x + W_out @ relu(W_in @ x + b_in) + b_out."""

    def __init__(self, dim=16, hidden=32):
        super().__init__()
        self.inp = nn.Linear(dim, hidden)
        self.out = nn.Linear(hidden, dim)

    def forward(self, x):
        return x + self.out(torch.relu(self.inp(x)))


class ReassembledResNet(nn.Module):
    """Full reconstructed model: proj -> 32 ResBlocks -> last."""

    def __init__(self, num_blocks=32, in_dim=784, hidden_dim=16, mid_dim=32, num_classes=10):
        super().__init__()
        self.proj = nn.Linear(in_dim, hidden_dim)
        self.blocks = nn.ModuleList(ResBlock(hidden_dim, mid_dim) for _ in range(num_blocks))
        self.last = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.proj(x)
        for block in self.blocks:
            x = block(x)
        return self.last(x)

    @torch.no_grad()
    def load_pieces(self, proj_layer, last_layer, ordered_blocks):
        """Copy the recovered weight tensors into this module's parameters."""
        self.proj.weight.copy_(proj_layer["weight"])
        self.proj.bias.copy_(proj_layer["bias"])
        self.last.weight.copy_(last_layer["weight"])
        self.last.bias.copy_(last_layer["bias"])

        for block, piece in zip(self.blocks, ordered_blocks):
            block.inp.weight.copy_(piece["inp_weight"])
            block.inp.bias.copy_(piece["inp_bias"])
            block.out.weight.copy_(piece["out_weight"])
            block.out.bias.copy_(piece["out_bias"])

# %%
def create_submission_csv_from_blocks(blocks, output_path=SUBMISSION_OUT):
    """Write the recovered block order (by source filename) to a CSV."""
    rows = [
        {
            "block_index": idx,
            "inp_piece": block["inp_filename"],
            "out_piece": block["out_filename"],
        }
        for idx, block in enumerate(blocks)
    ]

    submission = pd.DataFrame(rows)
    submission.to_csv(output_path, index=False)
    return submission

# %%
# --- Final verification ---
model = ReassembledResNet()
model.load_pieces(proj_layer, last_layer, final_seq)
model.eval()

with torch.no_grad():
    check_mse = torch.mean((model(X) - target_logits) ** 2).item()
print(f"Final model forward-pass MSE: {check_mse:.8f}")

# %%
# --- Save outputs ---
torch.save(
    {
        "state_dict": model.state_dict(),
        "architecture": "ReassembledResNet",
        "config": {
            "num_blocks": 32,
            "in_dim": 784,
            "hidden_dim": 16,
            "mid_dim": 32,
            "num_classes": 10,
        },
        "mse": check_mse,
    },
    MODEL_OUT,
)
print(f"Saved {MODEL_OUT}")

create_submission_csv_from_blocks(final_seq, SUBMISSION_OUT)
print(f"Saved {SUBMISSION_OUT}")
