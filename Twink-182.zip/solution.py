import os
import torch
import csv
import numpy as np
import random
import math

# Load data
with open("data/history_data.csv", "r") as f:
    reader = csv.reader(f)
    header = next(reader)
    data = []
    for row in reader:
        data.append([float(x) for x in row])
data = np.array(data)

pixel_cols = [i for i, h in enumerate(header) if h.startswith("pixel_")]
X = torch.tensor(data[:, pixel_cols], dtype=torch.float32)

logit_cols = [i for i, h in enumerate(header) if h.startswith("pred_logit_")]
target_logits = torch.tensor(data[:, logit_cols], dtype=torch.float32)

pieces_dir = "data/pieces"
piece_files = sorted([f for f in os.listdir(pieces_dir) if f.endswith(".pth")])

proj_layer = None
last_layer = None
inp_pieces = []
out_pieces = []

for filename in piece_files:
    filepath = os.path.join(pieces_dir, filename)
    piece = torch.load(filepath, map_location="cpu")
    weight = piece['weight']
    bias = piece['bias']
    
    if weight.shape == (16, 784):
        proj_layer = {'filename': filename, 'weight': weight, 'bias': bias}
    elif weight.shape == (10, 16):
        last_layer = {'filename': filename, 'weight': weight, 'bias': bias}
    elif weight.shape == (32, 16):
        inp_pieces.append({'filename': filename, 'weight': weight, 'bias': bias})
    elif weight.shape == (16, 32):
        out_pieces.append({'filename': filename, 'weight': weight, 'bias': bias})

# Pair blocks
blocks = []
for p_in in inp_pieces:
    W_in = p_in['weight']
    best_out = None
    best_diff = float('inf')
    for p_out in out_pieces:
        W_out = p_out['weight']
        diff = torch.norm(W_out + W_in.t()).item()
        if diff < best_diff:
            best_diff = diff
            best_out = p_out
    blocks.append({
        'inp': p_in,
        'out': best_out,
        'b_in_mean': p_in['bias'].mean().item()
    })

def apply_block(x, block):
    w_in, b_in = block['inp']['weight'], block['inp']['bias']
    w_out, b_out = block['out']['weight'], block['out']['bias']
    return x + torch.relu(x @ w_in.t() + b_in) @ w_out.t() + b_out

def apply_last(x):
    return x @ last_layer['weight'].t() + last_layer['bias']

# Precompute initial H
H0 = X @ proj_layer['weight'].t() + proj_layer['bias']

def eval_seq(seq):
    H = H0
    for idx in seq:
        H = apply_block(H, blocks[idx])
    return torch.mean((apply_last(H) - target_logits) ** 2).item()

# Start from the best found so far
sorted_indices = list(range(len(blocks)))
sorted_indices.sort(key=lambda i: blocks[i]['b_in_mean'])
curr_seq = list(sorted_indices)
curr_mse = eval_seq(curr_seq)

best_seq = list(curr_seq)
best_mse = curr_mse

T = 1.0
T_min = 1e-5
alpha = 0.9995

iter_count = 0
print(f"Starting SA with MSE: {best_mse:.6f}")

while T > T_min and best_mse > 1e-6:
    # Propose neighbor (swap 2)
    i, j = random.sample(range(32), 2)
    new_seq = curr_seq.copy()
    new_seq[i], new_seq[j] = new_seq[j], new_seq[i]
    
    new_mse = eval_seq(new_seq)
    delta = new_mse - curr_mse
    
    if delta < 0 or math.exp(-delta / T) > random.random():
        curr_seq = new_seq
        curr_mse = new_mse
        if curr_mse < best_mse:
            best_mse = curr_mse
            best_seq = list(curr_seq)
            print(f"Iter {iter_count}: New Best MSE: {best_mse:.8f}")
            
    T *= alpha
    iter_count += 1

print(f"Finished SA. Best MSE: {best_mse:.8f}")

if best_mse < 1e-4:
    with open("submission.csv", "w") as f:
        f.write("block_index,inp_piece,out_piece\n")
        for i, idx in enumerate(best_seq):
            b = blocks[idx]
            f.write(f"{i},{b['inp']['filename']},{b['out']['filename']}\n")
    print("Saved submission.csv")

